# LoginTemplate

![screenshot 1](https://github.com/qureshiayaz29/LoginTemplate/blob/master/screenshot/Screenshot_1.png)

![screenshot 2](https://github.com/qureshiayaz29/LoginTemplate/blob/master/screenshot/Screenshot_2.png)

![screenshot 3](https://github.com/qureshiayaz29/LoginTemplate/blob/master/screenshot/Screenshot_3.png)
